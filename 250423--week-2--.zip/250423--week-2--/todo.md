Git
Objective: Learn modules, exception handling, and Git basics.

Topics: List/dict comprehensions, os, datetime, Git workflow.

Tasks:

- (1) Write a mini file organizer that moves files by extension.

- (2) Push all code to GitHub.

- (3) Daily git practice: branch creation, commits, pull/push.

Django Introduction
Objective: Set up and understand a Django project.

Topics: MTV architecture, project vs app, admin panel.

Tasks:

- (4)
Set up a blog project.

Add 2 models: Post and Comment.

Enable CRUD via admin panel.